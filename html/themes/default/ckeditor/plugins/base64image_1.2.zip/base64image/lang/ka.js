/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","ka",{
	"alt":"სანაცვლო ტექსტი",
	"lockRatio":"პროპორციის შენარჩუნება",
	"vSpace":"ჰორიზონტალური სივრცე",
	"hSpace":"ვერტიკალური სივრცე",
	"border":"ჩარჩო"
});